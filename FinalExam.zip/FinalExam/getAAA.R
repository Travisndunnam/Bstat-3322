# getAAA
rm(list=ls())
Temperature <- c( rnorm( 30, 20, 11 ),
                  rnorm( 31, 12, 16 ),
                  rnorm( 28, 24, 12))
beta0 <- rnorm( 1, 50, 5 )
beta1 <- runif( 1, -0.5, -0.0 )
sigma <- runif( 1, 20, 40 )
ManDays <- 
    beta0 + beta1 * Temperature + 
    rnorm( length(Temperature), sigma  )
Temperature <- round( Temperature, 0 )
ManDays <- round( ManDays, 1)
summary( lm( ManDays ~ Temperature))
qplot( x=Temperature, y=ManDays )
AAA <- data.frame( Temperature, ManDays )
write.csv( AAA, file="AAA.csv" )
rm( list=ls() )
