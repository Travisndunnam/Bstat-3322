# getStock.R
rm( list=ls())
df <- round( runif( 1, 3, 10 ))
n <- runif( 1, 1, 10 )
n <- round( 250 * n )
MMR <- round( rnorm( 1, 0, 0.005 ), 4 )
SMR <- runif( 1, 0.001, 0.005)
BETA0 <- rnorm( 1, 0.0030, 0.001 )
BETA1 <- runif( 1, -0.005, 0.005 )
SIGMA <- runif( 1, 0.002, 0.006 )
Market <- BETA0 + SMR * rt( n, df )
Stock <- BETA0 + BETA1 * Market

Stock <- Stock + SIGMA * rnorm( n, 0, SIGMA )
Returns <- data.frame( Market, Stock  )
require( ggplot2 )
write.csv( Returns, file="Returns.csv" )
lm( kist=ls())