rm( list=ls())
n <- round( runif( 1, 1000, 1500 ))
BETA0 <- rnorm( 1, 6.0, 0.25 )
BETA1 <- runif( 1, 0.3, 0.7  )
CSmu  <- log( runif( 1, 3, 8 ))
CSsi  <- runif(1,  0.40, 0.60 )
RSpd <- rlnorm( n, CSmu, CSsi )
CSpd <- BETA0 + BETA1 * RSpd
CSpd <- CSpd + rnorm( n, 0, 1.5 )
Zeros <- CSpd == 0
RSpd <- RSpd[!Zeros]
CSpd <- CSpd[!Zeros]
Wind <- data.frame( RSpd, CSpd )
write.csv( Wind, file="Wind.csv")
rm(list=ls())

